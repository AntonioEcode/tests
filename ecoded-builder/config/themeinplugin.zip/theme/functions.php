<?php

/******************************************************************************/
/*                               Custom Shortcodes                            */
/******************************************************************************/
require WPEB_PLUGIN_THEME . 'functions/shortcodes/custom-shortcodes.php';

/******************************************************************************/
/*                           Load template parts                              */
/******************************************************************************/
require WPEB_PLUGIN_THEME . 'functions/templates/load-templates.php';

/******************************************************************************/
/*                               Remove editor                                */
/******************************************************************************/
require WPEB_PLUGIN_THEME . 'functions/remove-editor.php';

/******************************************************************************/
/*                    Create page settings for the footer                     */
/******************************************************************************/
if( file_exists( WPEB_PLUGIN_THEME . 'functions/footer-settings.php' ) ) {

	require WPEB_PLUGIN_THEME . 'functions/footer-settings.php';

}

?>