<?php

$current_id = get_the_ID();

?>
<ul class="list_comments">
    <?php

    wp_list_comments(
        array(
            'walker' => new walker_comments()
        )
    );

    ?>
</ul>
<section class="form_comment">
    <h3 class="title"><?php echo __( 'Deja un comentario', 'frontecode' ); ?></h3>
    <p class="desc"><?php echo __( 'Tu dirección de correo electrónico no será publicada. Los campos obligatorios están marcados con *', 'frontecode' ); ?></p>
    <form action="<?php echo get_bloginfo( 'url' ) . '/wp-comments-post.php'; ?>" method="post" id="commentform" class="comment-form">
        <div class="container_input_group">
            <div class="container_input">
                <input id="author" class="field_required" name="author" type="text" value="" placeholder="Nombre*" size="30">
            </div>
            <div class="container_input">
                <input id="email" class="field_required" name="email" type="email" value="" placeholder="Email*" size="30">
            </div>
        </div>
        <div class="container_input">
            <textarea placeholder="Comentario*" class="field_required" id="comment" name="comment" cols="45" rows="8" aria-required="true"></textarea>
        </div>
        <div class="terms_submit">
            <div class="terms">
                <input type="checkbox" id="comment_terms">
                <label for="comment_terms"><p><?php echo __( 'He leído y acepto las Condiciones del servicio y la Política de privacidad', 'frontecode' ); ?></p></label>
            </div>
            <input name="submit" type="submit" id="submit" class="submit ecode_button ecode_button_primary button_disabled" value="Enviar comentario">
            <input type="hidden" name="comment_post_ID" value="<?php echo $current_id; ?>" id="comment_post_ID">
            <input type="hidden" name="comment_parent" id="comment_parent" value="0">
        </div>
    </form>
</section>
