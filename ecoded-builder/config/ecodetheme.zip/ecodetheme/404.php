<?php

get_header();

?>
<div class="container_404">
	<h1><?php echo __( '404 Página no encontrada', 'frontecode' ); ?></h1>
	<div class="container_buttons">
		<a href="<?php echo get_bloginfo( 'url' ); ?>" class="ecode_button ecode_button_primary"><?php echo __( 'Ir a inicio', 'frontecode' ); ?></a>
	</div>
</div>
<?php

get_footer();

?>
