        </div>
        <?php

        get_template_part( 'template-parts/footer/content', 'footer' );

        get_template_part( 'template-parts/footer/content', 'scripts' );

        get_template_part( 'template-parts/footer/content', 'scripts-cookies' );

        wp_footer();

        ?>
    </body>
</html>
