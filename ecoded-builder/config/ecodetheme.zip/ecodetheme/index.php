<?php

get_header();

?>
<div class="container_page">
	<?php

	the_title( '<h1>', '</h1>' );

	?>
	<div class="container_content">
		<?php

		if( have_posts() ) :

			// Start the loop.
			while( have_posts() ) : the_post();

				the_content();

			// End the loop.
			endwhile;

		else :

		?>
		<p><?php echo __( 'No hay nada para mostrar.', 'frontecode' ); ?></p>
		<?php

		endif;

		?>
	</div>
</div>
<?php

get_footer();

?>
