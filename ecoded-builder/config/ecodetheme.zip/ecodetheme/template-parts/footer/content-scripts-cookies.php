<?php

$wpeb_cookies_enable = get_option( 'wpeb_cookies_enable' );
$wpeb_cookies_modal_title = get_option( 'wpeb_cookies_modal_title' );
$wpeb_cookies_modal_description = get_option( 'wpeb_cookies_modal_description' );
$wpeb_cookies_modal_config_button = get_option( 'wpeb_cookies_modal_config_button' );
$wpeb_cookies_modal_accept = get_option( 'wpeb_cookies_modal_accept' );
$wpeb_cookies_modal_decline = get_option( 'wpeb_cookies_modal_decline' );
$wpeb_cookies_popup_title = get_option( 'wpeb_cookies_popup_title' );
$wpeb_cookies_popup_author_name = get_option( 'wpeb_cookies_popup_author_name' );
$wpeb_cookies_popup_author_link = get_option( 'wpeb_cookies_popup_author_link' );
$wpeb_cookies_popup_save_button = get_option( 'wpeb_cookies_popup_save_button' );
$wpeb_cookies_popup_accept_all_button = get_option( 'wpeb_cookies_popup_accept_all_button' );
$wpeb_cookies_popup_cookies_usage_title = get_option( 'wpeb_cookies_popup_cookies_usage_title' );
$wpeb_cookies_popup_cookies_usage_description = get_option( 'wpeb_cookies_popup_cookies_usage_description' );
$wpeb_cookies_popup_cookies_analytics_title = get_option( 'wpeb_cookies_popup_cookies_analytics_title' );
$wpeb_cookies_popup_cookies_analytics_description = get_option( 'wpeb_cookies_popup_cookies_analytics_description' );
$wpeb_cookies_popup_more_info_title = get_option( 'wpeb_cookies_popup_more_info_title' );
$wpeb_cookies_popup_more_info_description = get_option( 'wpeb_cookies_popup_more_info_description' );

if( !empty( $wpeb_cookies_enable ) ) {

?>
<script type="text/javascript">

(function(){function na(za){function oa(a,b){return a.classList?a.classList.contains(b):!!a.className.match(new RegExp("(\\s|^)"+b+"(\\s|$)"))}function ha(a,b){a.classList?a.classList.remove(b):a.className=a.className.replace(new RegExp("(\\s|^)"+b+"(\\s|$)")," ")}function C(a,b){a.classList?a.classList.add(b):oa(a,b)||(a.className+=" "+b)}function Z(a){if("object"===typeof a){var b=[],c=0;for(b[c++]in a);return b}}function I(a,b,c,d){a.addEventListener?d?a.addEventListener(b,c,{passive:!0}):a.addEventListener(b,
c,!1):a.attachEvent("on"+b,c)}function ca(a,b,c){if("one"===b)var d=(d=document.cookie.match("(^|;)\\s*"+a+"\\s*=\\s*([^;]+)"))?c?d.pop():a:"";else if("all"===b)for(a=document.cookie.split(/;\s*/),d=[],b=0;b<a.length;b++)d.push(a[b].split("=")[0]);return d}function pa(){if(qa){var a=document.querySelectorAll("script[data-cookiecategory]"),b=ra,c=JSON.parse(J).level||[],d=function(f,h){if(h<f.length){var k=f[h],l=k.getAttribute("data-cookiecategory");if(-1<M(c,l)){k.type="text/javascript";k.removeAttribute("data-cookiecategory");
l=k.getAttribute("data-src");var g=e("script");g.textContent=k.innerHTML;(function(m,r){for(var w=r.attributes,B=w.length,N=0;N<B;N++)r=w[N],m.setAttribute(r.nodeName,r.nodeValue)})(g,k);l?g.src=l:l=k.src;l&&(b?g.readyState?g.onreadystatechange=function(){if("loaded"===g.readyState||"complete"===g.readyState)g.onreadystatechange=null,d(f,++h)}:g.onload=function(){g.onload=null;d(f,++h)}:l=!1);k.parentNode.replaceChild(g,k);if(l)return}d(f,++h)}};d(a,0)}}function Aa(a){function b(d,f,h,k,l,g,m){g=
g&&g.split(" ")||[];if(-1<M(f,l)&&(C(d,l),-1<M(h,g[0])))for(f=0;f<g.length;f++)C(d,g[f]);-1<M(k,m)&&C(d,m)}if("object"===typeof a){var c=a.consent_modal;a=a.settings_modal;Q&&c&&b(z,["box","bar","cloud"],["top","bottom"],["zoom","slide"],c.layout,c.position,c.transition);a&&b(D,["bar"],["left","right"],["zoom","slide"],a.layout,a.position,a.transition)}}function Ba(){var a=!1,b=!1;I(document,"keydown",function(c){c=c||window.event;"Tab"===c.key&&(u&&(c.shiftKey?document.activeElement===u[0]&&(u[1].focus(),
c.preventDefault()):document.activeElement===u[1]&&(u[0].focus(),c.preventDefault()),b||aa||(b=!0,!a&&c.preventDefault(),c.shiftKey?u[3]?u[2]?u[2].focus():u[0].focus():u[1].focus():u[3]?u[3].focus():u[0].focus())),!b&&(a=!0))});document.contains&&I(L,"click",function(c){c=c||window.event;ia?O.contains(c.target)?aa=!0:(t.hideSettings(0),aa=!1):ba&&z.contains(c.target)&&(aa=!0)},!0)}function e(a){var b=document.createElement(a);"button"===a&&b.setAttribute("type",a);return b}function M(a,b){for(var c=
a.length,d=0;d<c;d++)if(a[d]==b)return d;return-1}function Ca(a,b){if("string"!==typeof a||""==a||document.getElementById("cc--style"))b();else{var c=e("style");c.id="cc--style";var d=new XMLHttpRequest;d.onreadystatechange=function(){4==this.readyState&&200==this.status&&(c.setAttribute("type","text/css"),c.styleSheet?c.styleSheet.cssText=this.responseText:c.appendChild(document.createTextNode(this.responseText)),document.getElementsByTagName("head")[0].appendChild(c),b())};d.open("GET",a);d.send()}}
function da(a,b){var c=document.querySelectorAll(".c-tgl")||[],d="",f=[],h=!1;if(0<c.length){switch(b){case -1:for(b=0;b<c.length;b++)c[b].checked?(d+='"'+c[b].value+'",',E[b]||(f.push(c[b].value),E[b]=!0)):E[b]&&(f.push(c[b].value),E[b]=!1);break;case 0:for(b=0;b<c.length;b++)c[b].disabled?(d+='"'+c[b].value+'",',E[b]=!0):(c[b].checked=!1,E[b]&&(f.push(c[b].value),E[b]=!1));break;case 1:for(b=0;b<c.length;b++)c[b].checked=!0,d+='"'+c[b].value+'",',E[b]||f.push(c[b].value),E[b]=!0}d=d.slice(0,-1);
if(a.autoclear_cookies&&R&&0<f.length){c=a.languages[F].settings_modal.blocks;b=c.length;var k=-1,l=ca("","all"),g=[S,"."+S];if("www."===S.slice(0,4)){var m=S.substr(4);g.push(m);g.push("."+m)}for(m=0;m<b;m++){var r=c[m];if(r.hasOwnProperty("toggle")&&!E[++k]&&r.hasOwnProperty("cookie_table")&&-1<M(f,r.toggle.value)){var w=r.cookie_table,B=Z(a.languages[F].settings_modal.cookie_table_headers[0])[0],N=w.length;"on_disable"===r.toggle.reload&&(h=!0);for(var K=0;K<N;K++){var n=w[K],G=[],v=n[B],q=n.is_regex||
!1,p=n.domain||null;n=n.path||!1;p&&(g=[p,"."+p]);if(q)for(q=0;q<l.length;q++)l[q].match(v)&&G.push(l[q]);else v=M(l,v),-1<v&&G.push(l[v]);if(0<G.length){v=g;n=n?n:"/";for(q=0;q<G.length;q++)for(p=0;p<v.length;p++)document.cookie=G[q]+"=; Path="+n+"; Domain="+v[p]+"; Expires=Thu, 01 Jan 1970 00:00:01 GMT;";"on_clear"===r.toggle.reload&&(h=!0)}}}}}}J='{"level": ['+d+"]}";if(!R||0<f.length)d=ea,c=J,b=new Date,b.setTime(b.getTime()+864E5*sa),d=d+"="+(c||"")+("; expires="+b.toUTCString())+"; Path="+ta+
";",d+=" SameSite="+ua+";",-1<location.hostname.indexOf(".")&&(d+=" Domain="+S+";"),"https:"===location.protocol&&(d+=" Secure;"),document.cookie=d;pa();if("function"===typeof a.onAccept&&!R)return R=!0,a.onAccept(JSON.parse(J));if("function"===typeof a.onChange&&0<f.length)a.onChange(JSON.parse(J));h&&window.location.reload()}function Da(a,b){L=e("div");L.id="cc--main";L.style.position="fixed";L.style.zIndex="1000000";L.innerHTML='\x3c!--[if lt IE 9 ]><div id="cc_div" class="cc_div ie"></div><![endif]--\x3e\x3c!--[if (gt IE 8)|!(IE)]>\x3c!--\x3e<div id="cc_div" class="cc_div"></div>\x3c!--<![endif]--\x3e';
var c=L.children[0],d=F,f="string"===typeof T.textContent?"textContent":"innerText";if(!a){z=e("div");var h=e("div"),k=e("div"),l=e("div"),g=e("div"),m=e("div"),r=e("button"),w=e("button"),B=e("div");z.id="cm";h.id="c-inr";k.id="c-inr-i";l.id="c-ttl";g.id="c-txt";m.id="c-bns";r.id="c-p-bn";w.id="c-s-bn";B.id="cm-ov";r.className="c-bn";w.className="c-bn c_link";l.setAttribute("role","heading");l.setAttribute("aria-level","2");z.setAttribute("role","dialog");z.setAttribute("aria-modal","true");z.setAttribute("aria-hidden",
"false");z.setAttribute("aria-labelledby","c-ttl");z.setAttribute("aria-describedby","c-txt");z.style.visibility=B.style.visibility="hidden";B.style.opacity=0;l.insertAdjacentHTML("beforeend",b.languages[d].consent_modal.title);g.insertAdjacentHTML("beforeend",b.languages[d].consent_modal.description);r[f]=b.languages[d].consent_modal.primary_btn.text;w[f]=b.languages[d].consent_modal.secondary_btn.text;var N=-1;"accept_all"==b.languages[d].consent_modal.primary_btn.role&&(N=1);I(r,"click",function(){t.hide();
da(b,N)});"accept_necessary"==b.languages[d].consent_modal.secondary_btn.role?I(w,"click",function(){t.hide();da(b,0)}):I(w,"click",function(){t.showSettings(0)});k.appendChild(l);k.appendChild(g);m.appendChild(r);m.appendChild(w);h.appendChild(k);h.appendChild(m);z.appendChild(h);c.appendChild(z);c.appendChild(B)}D=e("div");h=e("div");k=e("div");l=e("div");O=e("div");g=e("div");m=e("div");var K=e("button");r=e("div");w=e("div");B=e("div");D.id="s-cnt";h.id="c-vln";l.id="c-s-in";k.id="cs";g.id="s-ttl";
O.id="s-inr";m.id="s-hdr";w.id="s-bl";K.id="s-c-bn";B.id="cs-ov";r.id="s-c-bnc";K.className="c-bn";K.setAttribute("aria-label",b.languages[d].settings_modal.close_btn_label||"Close");D.setAttribute("role","dialog");D.setAttribute("aria-modal","true");D.setAttribute("aria-hidden","true");D.setAttribute("aria-labelledby","s-ttl");g.setAttribute("role","heading");D.style.visibility=B.style.visibility="hidden";B.style.opacity=0;r.appendChild(K);I(h,"keydown",function(U){U=U||window.event;27==U.keyCode&&
t.hideSettings(0)},!0);I(K,"click",function(){t.hideSettings(0)});d=b.languages[F].settings_modal.blocks;K=d.length;g.insertAdjacentHTML("beforeend",b.languages[F].settings_modal.title);for(var n=0;n<K;++n){var G=e("div"),v=e("div"),q=e("div"),p=e("div");G.className="c-bl";v.className="desc";q.className="p";p.className="title";q.insertAdjacentHTML("beforeend",d[n].description);if("undefined"!==typeof d[n].toggle){var x="c-ac-"+n,P=e("button"),H=e("label"),y=e("input"),A=e("span"),V=e("span"),W=e("span"),
X=e("span");P.className="b-tl";H.className="b-tg";y.className="c-tgl";W.className="on-i";X.className="off-i";A.className="c-tg";V.className="t-lb";P.setAttribute("aria-expanded","false");P.setAttribute("aria-controls",x);y.type="checkbox";A.setAttribute("aria-hidden","true");var va=d[n].toggle.value;y.value=va;V[f]=d[n].title;P.insertAdjacentHTML("beforeend",d[n].title);p.appendChild(P);A.appendChild(W);A.appendChild(X);a?-1<M(JSON.parse(J).level,va)?(y.checked=!0,E.push(!0)):E.push(!1):d[n].toggle.enabled&&
(y.checked=!0);d[n].toggle.readonly&&(y.disabled=!0,y.setAttribute("aria-readonly","true"),C(A,"c-ro"));C(v,"b-acc");C(p,"b-bn");C(G,"b-ex");v.id=x;v.setAttribute("aria-hidden","true");H.appendChild(y);H.appendChild(A);H.appendChild(V);p.appendChild(H);(function(U,ja,wa){I(P,"click",function(){oa(ja,"act")?(ha(ja,"act"),wa.setAttribute("aria-expanded","false"),U.setAttribute("aria-hidden","true")):(C(ja,"act"),wa.setAttribute("aria-expanded","true"),U.setAttribute("aria-hidden","false"))},!1)})(v,
G,P)}else x=e("div"),x.className="b-tl",x.setAttribute("role","heading"),x.setAttribute("aria-level","3"),x.insertAdjacentHTML("beforeend",d[n].title),p.appendChild(x);G.appendChild(p);v.appendChild(q);if(!0!==b.remove_cookie_tables&&"undefined"!==typeof d[n].cookie_table){H=document.createDocumentFragment();q=b.languages[F].settings_modal.cookie_table_headers;for(y=0;y<q.length;++y)A=e("th"),p=q[y],A.setAttribute("scope","col"),p&&(x=p&&Z(p)[0],A[f]=q[y][x],H.appendChild(A));p=e("tr");p.appendChild(H);
x=e("thead");x.appendChild(p);H=e("table");H.appendChild(x);y=document.createDocumentFragment();for(A=0;A<d[n].cookie_table.length;A++){V=e("tr");for(W=0;W<q.length;++W)if(p=q[W])x=Z(p)[0],X=e("td"),X.insertAdjacentHTML("beforeend",d[n].cookie_table[A][x]),X.setAttribute("data-column",p[x]),V.appendChild(X);y.appendChild(V)}q=e("tbody");q.appendChild(y);H.appendChild(q);v.appendChild(H)}G.appendChild(v);w.appendChild(G)}a=e("div");f=e("button");d=e("button");a.id="s-bns";f.id="s-sv-bn";d.id="s-all-bn";
f.className="c-bn";d.className="c-bn";f.insertAdjacentHTML("beforeend",b.languages[F].settings_modal.save_settings_btn);d.insertAdjacentHTML("beforeend",b.languages[F].settings_modal.accept_all_btn);a.appendChild(d);a.appendChild(f);I(f,"click",function(){t.hideSettings();t.hide();da(b,-1)});I(d,"click",function(){t.hideSettings();t.hide();da(b,1)});m.appendChild(g);m.appendChild(r);O.appendChild(m);O.appendChild(w);O.appendChild(a);l.appendChild(O);k.appendChild(l);h.appendChild(k);D.appendChild(h);
c.appendChild(D);c.appendChild(B);(za||document.body).appendChild(L)}function Ea(){function a(c,d){var f=!1,h=!1;try{for(var k=c.querySelectorAll(b.join(':not([tabindex="-1"]), ')),l,g=k.length,m=0;m<g;)l=k[m].getAttribute("data-focus"),h||"1"!==l?"0"===l&&(f=k[m],h||"0"===k[m+1].getAttribute("data-focus")||(h=k[m+1])):h=k[m],m++}catch(r){return c.querySelectorAll(b.join(", "))}d[0]=k[0];d[1]=k[k.length-1];d[2]=f;d[3]=h}var b=["[href]","button","input","details",'[tabindex="0"]'];a(O,Y);Q&&a(z,ka)}
function xa(a,b){if(b.hasOwnProperty(a))return a;if(0<Z(b).length)return b.hasOwnProperty(F)?F:Z(b)[0]}function Fa(){for(var a=document.querySelectorAll('a[data-cc="c-settings"], button[data-cc="c-settings"]'),b=0;b<a.length;b++)a[b].setAttribute("aria-haspopup","dialog"),I(a[b],"click",function(c){t.showSettings(0);c.preventDefault?c.preventDefault():c.returnValue=!1})}function Ga(a){"number"===typeof a.cookie_expiration&&(sa=a.cookie_expiration);"boolean"===typeof a.autorun&&(ya=a.autorun);"string"===
typeof a.cookie_domain&&(S=a.cookie_domain);"string"===typeof a.cookie_same_site&&(ua=a.cookie_same_site);"string"===typeof a.cookie_path&&(ta=a.cookie_path);"string"===typeof a.cookie_name&&(ea=a.cookie_name);qa=!0===a.page_scripts;ra=!1!==a.page_scripts_order;if(!0===a.auto_language){var b=navigator.language||navigator.browserLanguage;2<b.length&&(b=b[0]+b[1]);F=xa(b.toLowerCase(),a.languages)}else"string"===typeof a.current_lang&&(F=xa(a.current_lang,a.languages));!0===a.force_consent&&C(T,"force--consent")}
var F="en",ya=!0,ea="cc_cookie",sa=182,S=location.hostname,ta="/",ua="Lax",qa,ra,t={},J,Q=!1,R=!1,ba=!1,ia=!1,aa=!1,u,fa,la,ka=[],Y=[],E=[],T=document.documentElement,L,z,D,O;t.allowedCategory=function(a){return-1<M(JSON.parse(ca(ea,"one",!0)||"{}").level||[],a)};t.run=function(a){if(!L&&(Ga(a),J=ca(ea,"one",!0),Q=""==J,Da(!Q,a),Ca(a.theme_css,function(){Ea();Aa(a.gui_options);Fa();!J&&ya&&t.show(a.delay||0);setTimeout(function(){C(L,"c--anim")},30);setTimeout(function(){Ba()},100)}),J&&(R=!0),R&&
(pa(),"function"===typeof a.onAccept)))a.onAccept(JSON.parse(J||"{}"))};t.showSettings=function(a){setTimeout(function(){C(T,"show--settings");D.setAttribute("aria-hidden","false");ia=!0;ba?la=document.activeElement:fa=document.activeElement;setTimeout(function(){0!==Y.length&&(Y[3]?Y[3].focus():Y[0].focus(),u=Y)},100)},0<a?a:0)};t.loadScript=function(a,b,c){var d="function"===typeof b;if(document.querySelector('script[src="'+a+'"]'))d&&b();else{var f=e("script");if(c&&0<c.length)for(var h=0;h<c.length;++h)c[h]&&
f.setAttribute(c[h].name,c[h].value);d&&(f.readyState?f.onreadystatechange=function(){if("loaded"===f.readyState||"complete"===f.readyState)f.onreadystatechange=null,b()}:f.onload=b);f.src=a;(document.head?document.head:document.getElementsByTagName("head")[0]).appendChild(f)}};t.show=function(a){Q&&setTimeout(function(){C(T,"show--consent");z.setAttribute("aria-hidden","false");ba=!0;fa=document.activeElement;u=ka},0<a?a:0)};t.hide=function(){Q&&(ha(T,"show--consent"),z.setAttribute("aria-hidden",
"true"),ba=!1,fa.focus(),u=null)};t.hideSettings=function(){ha(T,"show--settings");ia=!1;D.setAttribute("aria-hidden","true");ba?(la&&la.focus(),u=ka):(fa.focus(),u=null);aa=!1};t.validCookie=function(a){return""!=ca(a,"one",!0)};return na=window[ma]=void 0,t}var ma="initCookieConsent";"function"!==typeof window[ma]&&(window[ma]=na)})();

setTimeout(function(){

    // Initialize cookie consent
    var cookie_consent = initCookieConsent();

    // Run cookie consent
    cookie_consent.run({
        autorun : true,
        delay : 0,
        current_lang : 'es',
        autoclear_cookies : true,
        cookie_expiration : 365,
        force_consent: false,
        page_scripts: false,
        gui_options : {
            consent_modal : {
                layout : 'box',
                position: 'bottom right',
                transition: 'slide'
            },
            settings_modal : {
                layout : 'box',
                transition : 'slide'
            }
        },
        languages : {
            'es' : {
                consent_modal : {
                    title : '<?php echo $wpeb_cookies_modal_title; ?>',
                    description : '<?php echo $wpeb_cookies_modal_description; ?> <button type="button" data-cc="c-settings" class="cc-link"><?php echo $wpeb_cookies_modal_config_button; ?></button>',
                    primary_btn: {
                        text: '<?php echo $wpeb_cookies_modal_accept; ?>',
                        role: 'accept_all'
                    },
                    secondary_btn: {
                        text : '<?php echo $wpeb_cookies_modal_decline; ?>',
                        role : 'accept_necessary'
                    }
                },
                settings_modal : {
                    title : '<div><?php echo $wpeb_cookies_popup_title; ?></div><div aria-hidden="true" style="font-size: .8em; font-weight: 200; color: #687278; margin-top: 5px;">by <a aria-hidden="true" href="<?php echo $wpeb_cookies_popup_author_link; ?>" style="text-decoration: underline;" target="_blank"><?php echo $wpeb_cookies_popup_author_name; ?></a></div>',
                    save_settings_btn : "<?php echo $wpeb_cookies_popup_save_button; ?>",
                    accept_all_btn : "<?php echo $wpeb_cookies_popup_accept_all_button; ?>",
                    close_btn_label: 'Close',
                    cookie_table_headers : [
                        {col1: 'Nombre' },
                        {col2: 'Dominio' },
                        {col3: 'Expiración' },
                        {col4: 'Descripción' }
                    ],
                    blocks : [
                        {
                            title : '<?php echo $wpeb_cookies_popup_cookies_usage_title; ?>',
                            description: '<?php echo $wpeb_cookies_popup_cookies_usage_description; ?>'
                        },
                        {
                            title : '<?php echo $wpeb_cookies_popup_cookies_analytics_title; ?>',
                            description: '<?php echo $wpeb_cookies_popup_cookies_analytics_description; ?>',
                            toggle : {
                                value : 'analytics',
                                enabled : true,
                                readonly: false
                            },
                            cookie_table: [
                                <?php

                                for( $i = 1; $i < 6; $i++ ) {

                                    $wpeb_cookies_popup_cookies_analytics_table_description = get_option( 'wpeb_cookies_popup_cookies_analytics_table_description_' . $i );
                                    $wpeb_cookies_popup_cookies_analytics_table_expiration = get_option( 'wpeb_cookies_popup_cookies_analytics_table_expiration_' . $i );
                                    $wpeb_cookies_popup_cookies_analytics_table_domain = get_option( 'wpeb_cookies_popup_cookies_analytics_table_domain_' . $i );
                                    $wpeb_cookies_popup_cookies_analytics_table_name = get_option( 'wpeb_cookies_popup_cookies_analytics_table_name_' . $i );

                                ?>
                                {
                                    col1: '<?php echo $wpeb_cookies_popup_cookies_analytics_table_name; ?>',
                                    col2: '<?php echo $wpeb_cookies_popup_cookies_analytics_table_domain; ?>',
                                    col3: '<?php echo $wpeb_cookies_popup_cookies_analytics_table_expiration; ?>',
                                    col4: '<?php echo $wpeb_cookies_popup_cookies_analytics_table_description; ?>'
                                },
                                <?php

                                }

                                ?>
                            ]
                        },
                        {
                            title : "<?php echo $wpeb_cookies_popup_more_info_title; ?>",
                            description: '<?php echo $wpeb_cookies_popup_more_info_description; ?>',
                        }
                    ]
                }
            }
        }
    });

}, 1500 );

</script>
<?php

}

?>
