<?php

$current_id = get_the_ID();

?>
<script type='text/javascript'>
	<?php

	include_once( 'scripts/js-ecode-general.min.php' );

	if( is_front_page() ) {

		include_once( 'scripts/js-template-106.168.min.php' );

		include_once( 'scripts/js-template-110.172.min.php' );

	}

	if( in_array( $current_id,  wpeb_get_template_by_name( 'service', $results = true ) ) ) {

		include_once( 'scripts/js-template-106.168.min.php' );

		include_once( 'scripts/js-template-110.172.min.php' );

	}

	if( in_array( $current_id,  wpeb_get_template_by_name( 'work', $results = true ) ) ) {

		include_once( 'scripts/js-template-106.168.min.php' );

		include_once( 'scripts/js-template-110.172.min.php' );

	}

	if( in_array( $current_id,  wpeb_get_template_by_name( 'contact', $results = true ) ) ) {

		include_once( 'scripts/js-template-106.168.min.php' );

		include_once( 'scripts/js-template-110.172.min.php' );

	}

	if( in_array( $current_id,  wpeb_get_template_by_name( 'about', $results = true ) ) ) {

		include_once( 'scripts/js-library-flickity.js.min.php' );

		include_once( 'scripts/js-template-106.168.min.php' );

		include_once( 'scripts/js-template-110.172.min.php' );

	}

	if( is_home() ) {

		include_once( 'scripts/js-template-106.168.min.php' );

		include_once( 'scripts/js-template-110.172.min.php' );

	}

	if( is_single( $current_id ) ) {

		include_once( 'scripts/js-template-106.168.min.php' );

		include_once( 'scripts/js-template-110.172.min.php' );

	}

	if( in_array( $current_id,  wpeb_get_template_by_name( 'services', $results = true ) ) ) {

		include_once( 'scripts/js-template-106.168.min.php' );

		include_once( 'scripts/js-template-110.172.min.php' );

	}

	if( in_array( $current_id,  wpeb_get_template_by_name( 'works', $results = true ) ) ) {

		include_once( 'scripts/js-template-106.168.min.php' );

		include_once( 'scripts/js-template-110.172.min.php' );

	}

	?>
</script>