<?php

if( !empty( get_option( 'ecode_analytics' ) ) ) {

?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo get_option( 'ecode_analytics' ); ?>"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', '<?php echo get_option( 'ecode_analytics' ); ?>');
</script>
<?php

}

?>
