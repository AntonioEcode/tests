<!DOCTYPE html>
<html lang="es" class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php

	get_template_part( 'template-parts/header/content', 'stylesheet' );

	wp_head();

	if( get_option( 'ecode_status_website' ) == 'production' ) {

		get_template_part( 'template-parts/header/content', 'analytics' );

	}

	get_template_part( 'template-parts/header/content', 'head' );

	?>
</head>
<body id="body" <?php body_class(); ?>>
	<?php

	// Desactivate error showing website
	error_reporting(0);

	get_template_part( 'template-parts/header/content', 'header' );

	?>
