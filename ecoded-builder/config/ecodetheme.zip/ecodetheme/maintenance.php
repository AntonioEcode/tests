<?php

header( 'HTTP/1.1 503 Service Temporarily Unavailable' );

$blog_url = get_bloginfo( 'url' ) . '/';

$logo_id  = !empty( get_option( 'wpeb_logo' ) ) ? get_option( 'wpeb_logo' ) : '';

// Check if contains URL or int
if( !empty( $logo_id ) ) {

	if( is_numeric( $logo_id ) ) {

		$logo_src = wp_get_attachment_image_src( $logo_id, 'full' )[0];
		$logo_alt = get_post_meta( $logo_id, '_wp_attachment_image_alt', TRUE );
		$logo_alt = !empty( $logo_alt ) ? $logo_alt : get_bloginfo( 'name' );

	} elseif( is_string( $logo_id ) ) {

		$logo_src = $logo_id;
		$logo_alt = get_bloginfo( 'name' );

	}

}

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
		<link rel="profile" href="http://gmpg.org/xfn/11">
		<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
		<?php wp_head(); ?>
		<header>
			<div class="header_width">
				<a href="<?php echo $blog_url; ?>" class="logo">
					<picture>
						<img src="<?php echo $logo_src; ?>" alt="<?php echo $logo_alt; ?>">
					</picture>
				</a>
				
			</div>
		</header>
	</head>
	<body class="page-maintenance">
		<h1><?php echo __( 'Web en mantenimiento', 'frontecode' ); ?></h1>
		<p><b><?php echo __( 'Estaremos de vuelta en breves momentos, disculpa las molestias.', 'frontecode' ); ?></b></p>
		
	</body>
</html>